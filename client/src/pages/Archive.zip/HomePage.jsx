import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import "./HomePage.css";

const HomePage = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [roomId, setRoomId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    // Trigger animation after component mounts
    setShowAnimation(true);
    // Always start with empty username
    setUsername("");
  }, []);

  const handleJoin = () => {
    if (!username.trim()) {
      alert("Please enter your name");
      return;
    }

    if (!roomId.trim()) {
      alert("Please enter a Room ID");
      return;
    }

    // Save username to localStorage
    localStorage.setItem("code-sync-username", username);

    setIsLoading(true);
    setTimeout(() => {
      navigate(`/editor/${roomId}`, { state: { username } });
    }, 800);
  };

  const handleCreateRoom = () => {
    const newRoomId = uuidv4().substring(0, 8);
    setRoomId(newRoomId);
  };

  return (
    <div className="home-container">
      <div className="background-elements">
        <div className="bg-circle circle-1"></div>
        <div className="bg-circle circle-2"></div>
        <div className="bg-circle circle-3"></div>
        <div className="code-pattern"></div>
      </div>

      <div className={`home-content ${showAnimation ? "animate-in" : ""}`}>
        <div className="brand">
          <div className="logo">
            <span className="logo-bracket">{`{`}</span>
            <span style={{ margin: "0 20px" }} className="logo-bracket">
              Code-Relo
            </span>
            <span className="logo-bracket">{`}`}</span>
          </div>
          <h1 className="title">Real-Time Collaborative Code Editor</h1>
          <p className="subtitle">
            Code together. Create together. In real-time.
          </p>
        </div>

        <div className="join-container">
          <div className="input-wrapper">
            <label htmlFor="username">Your Name</label>
            <input
              id="username"
              type="text"
              placeholder="Enter your name"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="input-wrapper">
            <label htmlFor="roomId">Room ID</label>
            <div className="room-input-group">
              <input
                id="roomId"
                type="text"
                placeholder="Enter room ID or create new"
                value={roomId}
                onChange={(e) => setRoomId(e.target.value)}
              />
              <button className="create-btn" onClick={handleCreateRoom}>
                Generate
              </button>
            </div>
          </div>

          <button
            className={`join-btn ${isLoading ? "loading" : ""}`}
            onClick={handleJoin}
            disabled={isLoading}
          >
            {isLoading ? <span className="loader"></span> : <>Join Session</>}
          </button>
        </div>

        <div className="features">
          <div className="feature">
            <div className="feature-icon">⚡</div>
            <div className="feature-text">
              <h3>Real-Time Collaboration</h3>
              <p>
                Code with your team in real-time, see changes as they happen
              </p>
            </div>
          </div>

          <div className="feature">
            <div className="feature-icon">🔄</div>
            <div className="feature-text">
              <h3>Multiple Languages</h3>
              <p>Support for JavaScript, Python, Java, and C++</p>
            </div>
          </div>

          <div className="feature">
            <div className="feature-icon">🔒</div>
            <div className="feature-text">
              <h3>Private Rooms</h3>
              <p>Create private coding sessions with unique room IDs</p>
            </div>
          </div>
        </div>
      </div>

      <footer className="home-footer">
        <p>© 2024 CodeSync • Designed with ❤️ by Tanish Upadhyay</p>
        <div className="social-links">
          <a
            href="https://github.com/tanishupadhyay"
            target="_blank"
            rel="noopener noreferrer"
          >
            GitHub
          </a>
          <a href="#resume" target="_blank" rel="noopener noreferrer">
            Resume
          </a>
          <a
            href="https://linkedin.com/in/tanishupadhyay"
            target="_blank"
            rel="noopener noreferrer"
          >
            LinkedIn
          </a>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
